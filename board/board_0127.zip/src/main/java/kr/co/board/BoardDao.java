package kr.co.board;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


public class BoardDao {

	private Connection conn=null;
	private Statement stmt=null;
	private PreparedStatement pstmt=null;
	private ResultSet rs=null;
	private String sql=null;
	
	public BoardDao() throws SQLException, ClassNotFoundException
	{
		Class.forName("com.mysql.jdbc.Driver"); 
		String aa="jdbc:mysql://localhost:3306/spring?useSSL=false";
		String bb="root";
		String cc="1234";
		conn = DriverManager.getConnection(aa,bb,cc);
	}
	
	public void write_ok(BoardDto bdto) throws SQLException // 폼입력값 => 테이블에 저장
	{
		// 쿼리작성
		sql="insert into board(name,title,content,pwd,writeday) ";
		sql=sql+" values(?,?,?,?,now())";
		// 심부름꾼 생성
		pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, bdto.getName());
		pstmt.setString(2, bdto.getTitle());
		pstmt.setString(3, bdto.getContent());
		pstmt.setString(4, bdto.getPwd());
		
		// 쿼리 실행
		pstmt.executeUpdate();
		
		pstmt.close();
		conn.close();
		
	}
	
	public ArrayList<BoardDto> list() throws SQLException
	{
		ArrayList<BoardDto> list=new ArrayList<BoardDto>();
		// DB에 있는 값 읽어옴
		// 쿼리 작성
		sql="select * from board order by id desc";
		// 심부름꾼
		stmt=conn.createStatement();
		// 쿼리실행
		rs=stmt.executeQuery(sql);
		// ArrayList에 Dto 담기
		while(rs.next()) 
		{
			BoardDto bdto=new BoardDto();
			bdto.setId(rs.getInt("id"));
			bdto.setName(rs.getString("name"));
			bdto.setTitle(rs.getString("title"));
			bdto.setContent(rs.getString("content"));
			bdto.setReadnum(rs.getInt("readnum"));
			bdto.setWriteday(rs.getString("writeday"));
			
			list.add(bdto);
		}
		return list;
	}
	
	public BoardDto content(String id) throws SQLException
	{
		sql="select * from board where id="+id;
		stmt=conn.createStatement();
		rs=stmt.executeQuery(sql);
		rs.next();
		BoardDto bdto=new BoardDto();
		bdto.setId(rs.getInt("id"));
		bdto.setName(rs.getString("name"));
		bdto.setTitle(rs.getString("title"));
		bdto.setContent(rs.getString("content"));
		bdto.setReadnum(rs.getInt("readnum"));
		bdto.setWriteday(rs.getString("writeday"));
		
		return bdto;
	}
	
	public BoardDto update(String id) throws SQLException
	{
		sql="select * from board where id="+id;
		stmt=conn.createStatement();
		rs=stmt.executeQuery(sql);
		rs.next();
		BoardDto bdto=new BoardDto();
		bdto.setId(rs.getInt("id"));
		bdto.setName(rs.getString("name"));
		bdto.setTitle(rs.getString("title"));
		bdto.setContent(rs.getString("content"));
		bdto.setReadnum(rs.getInt("readnum"));
		bdto.setWriteday(rs.getString("writeday"));
		
		return bdto;
	}
	
	public void update_ok(BoardDto bdto) throws SQLException
	{
		sql="update board set name=?, title=?, content=?  where id=?";
		pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, bdto.getName());
		pstmt.setString(2, bdto.getTitle());
		pstmt.setString(3, bdto.getContent());
		pstmt.setInt(4, bdto.getId());
		//System.out.println(pstmt.toString());
		pstmt.executeUpdate();
		
	}
	
	public void delete(String id) throws SQLException
	{
		sql="delete from board where id="+id;
		stmt=conn.createStatement();
		stmt.executeUpdate(sql);
	}
	
	public int pwd_check(String id,String pwd) throws SQLException
	{
		sql="select count(*) as cnt from board where id=? and pwd=?";
		pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, id);
		pstmt.setString(2, pwd);
		ResultSet rs=pstmt.executeQuery();
		rs.next();
		return rs.getInt("cnt");
	}
}















