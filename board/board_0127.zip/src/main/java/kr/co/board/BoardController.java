package kr.co.board;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class BoardController {

	@RequestMapping("/")
	public String main()
	{
		return "redirect:/list";
	}
	
	@RequestMapping("/write")
	public String write()
	{
		return "/write";
	}
	
	@RequestMapping("/write_ok")
	public String write_ok(BoardDto bdto) throws SQLException, ClassNotFoundException
	{
		// 폼에 입력된 값을 board테이블에 저장
		BoardDao bdao=new BoardDao();
		bdao.write_ok(bdto);
		return "redirect:/list"; // list로 이동
	}
	
	@RequestMapping("/list")
	public String list(Model model) throws ClassNotFoundException, SQLException
	{
		// Dao를 통해 테이블의 내용을 가져온다..
		BoardDao bdao=new BoardDao();
		ArrayList<BoardDto> list=bdao.list();
		// view에 테이블의 내용을 전달
		model.addAttribute("list",list);
		return "/list";
	}
	
	@RequestMapping("/content")
	public String content(Model model,HttpServletRequest request) throws ClassNotFoundException, SQLException
	{
		// dao를 통해 레코드를 1개를 가져온다
		// dao의 메소드를 호출할때 하나의 레코드의 unique한 값 => id
		String id=request.getParameter("id");
		BoardDao bdao=new BoardDao();
		BoardDto bdto=bdao.content(id);
		model.addAttribute("bdto",bdto);
		model.addAttribute("rn","\r\n");
		return "/content";
	}
	
	@RequestMapping("/update")
	public String update(Model model,HttpServletRequest request) throws ClassNotFoundException, SQLException
	{
		String id=request.getParameter("id");
		BoardDao bdao=new BoardDao();
		BoardDto bdto=bdao.update(id);
		model.addAttribute("bdto",bdto);
		return "/update";
	}
	
	@RequestMapping("/update_ok")
	public String update_ok(BoardDto bdto) throws SQLException, ClassNotFoundException
	{
		BoardDao bdao=new BoardDao();
		int cnt=bdao.pwd_check(bdto.getId()+"",bdto.getPwd());
		if(cnt != 0)
		{
			bdao.update_ok(bdto);
		}

		return "redirect:/content?id="+bdto.getId();
	}
	
	
	@RequestMapping("/delete")
    public String delete(HttpServletRequest request) throws ClassNotFoundException, SQLException
    {
		String id=request.getParameter("id");
		String pwd=request.getParameter("pwd");
		BoardDao bdao=new BoardDao();
		int cnt=bdao.pwd_check(id,pwd);
		if(cnt==0)
			return "redirect:/content?id="+id;
		else
		{
			bdao.delete(id);
		    return "redirect:/list";
		}
    }
	
	
}
